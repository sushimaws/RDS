'use strict';

const AWS = require('aws-sdk');
const postGres = require('pg');
//const docClient = new AWS.DynamoDB.DocumentClient();

    //instantiates a client to connect to the database, connection settings are passed in
    const client = new postGres({
        user: 'tpadmin',
        host: 'tpdb-instance-1.cibotfkkslx7.us-east-1.rds.amazonaws.com',
        database: 'tpdp',
        password: 'admin123',
       port: 5432
    });
     
    //the lambda funtion code
    exports.handler = async (event, context) => {
     
        try {
     
            await client.connect();
            return "Connected Successfully";
            //your code here
     
        } catch (err) {
     
            return "Failed to Connect Successfully";
            throw err;
            //error message
        }
     
        client.end();
    };
    